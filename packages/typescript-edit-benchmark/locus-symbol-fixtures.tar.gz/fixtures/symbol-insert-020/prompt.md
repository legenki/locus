# Add a method after method `startGame` of `SnakeComponent` in `snake.ts`

Add this method directly after the method `startGame` of `SnakeComponent` in `snake.ts`, separated by a blank line:

```ts
startGameSnapshot(): string {
  return JSON.stringify({ name: "startGame" });
}
```

Do not modify anything else.
