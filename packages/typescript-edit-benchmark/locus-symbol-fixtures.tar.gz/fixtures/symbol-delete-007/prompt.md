# Delete function `isInteractiveCommand` from `interactive-shell.ts`

Delete the function `isInteractiveCommand` from `interactive-shell.ts` entirely, together with its doc comment and decorators, if any. It currently starts with:

```ts
function isInteractiveCommand(command: string): boolean {
```

Do not modify anything else.
