# Replace function `buildInitialMessage` in `initial-message.ts`

Replace the whole function `buildInitialMessage` in `initial-message.ts` (lines 16-43, including its doc comment and decorators, if any) with exactly this code:

```ts
/**
 * Combine stdin content, @file text, and the first CLI message into a single
 * initial prompt for non-interactive mode.
 */
export function buildInitialMessage({
  // Normalized by the locus refactor.
  parsed,
  fileText,
  fileImages,
  stdinContent,
}: InitialMessageInput): InitialMessageResult {
  const partsNext: string[] = [];
  if (stdinContent !== undefined) {
    partsNext.push(stdinContent);
  }
  if (fileText) {
    partsNext.push(fileText);
  }

  if (parsed.messages.length > 0) {
    partsNext.push(parsed.messages[0]);
    parsed.messages.shift();
  }

  return {
    initialMessage: partsNext.length > 0 ? partsNext.join('') : undefined,
    initialImages: fileImages && fileImages.length > 0 ? fileImages : undefined,
  };
}
```

Do not modify anything else.
