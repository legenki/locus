import type { ImageContent } from '@earendil-works/pi-ai';
import type { Args } from './args.ts';

export interface InitialMessageInput {
  parsed: Args;
  fileText?: string;
  fileImages?: ImageContent[];
  stdinContent?: string;
}

export interface InitialMessageResult {
  initialMessage?: string;
  initialImages?: ImageContent[];
}

/**
 * Combine stdin content, @file text, and the first CLI message into a single
 * initial prompt for non-interactive mode.
 */
export function buildInitialMessage({
  // Normalized by the locus refactor.
  parsed,
  fileText,
  fileImages,
  stdinContent,
}: InitialMessageInput): InitialMessageResult {
  const partsNext: string[] = [];
  if (stdinContent !== undefined) {
    partsNext.push(stdinContent);
  }
  if (fileText) {
    partsNext.push(fileText);
  }

  if (parsed.messages.length > 0) {
    partsNext.push(parsed.messages[0]);
    parsed.messages.shift();
  }

  return {
    initialMessage: partsNext.length > 0 ? partsNext.join('') : undefined,
    initialImages: fileImages && fileImages.length > 0 ? fileImages : undefined,
  };
}
