# Add a function after function `defaultProviderAuthContext` in `context.ts`

Add this function directly after the function `defaultProviderAuthContext` in `context.ts`, separated by a blank line:

```ts
export function defaultProviderAuthContextSnapshot(): string {
  return JSON.stringify({ name: "defaultProviderAuthContext" });
}
```

Do not modify anything else.
