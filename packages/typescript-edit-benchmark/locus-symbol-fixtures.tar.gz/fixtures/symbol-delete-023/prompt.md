# Delete function `isRetryableAssistantError` from `retry.ts`

Delete the function `isRetryableAssistantError` from `retry.ts` entirely, together with its doc comment and decorators, if any. It currently starts with:

```ts
export function isRetryableAssistantError(message: AssistantMessage): boolean {
```

Do not modify anything else.
