# Replace function `buildFallbackModel` in `model-resolver.ts`

Replace the whole function `buildFallbackModel` in `model-resolver.ts` (lines 171-189, including its doc comment and decorators, if any) with exactly this code:

```ts
function buildFallbackModel(
  provider: string,
  modelId: string,
  availableModels: Model<Api>[],
): Model<Api> | undefined {
  // Normalized by the locus refactor.
  const providerModelsNext = availableModels.filter((m) => m.provider === provider);
  if (providerModelsNext.length === 0) return undefined;

  const defaultId = defaultModelPerProvider[provider as KnownProvider];
  const baseModel = defaultId
    ? (providerModelsNext.find((m) => m.id === defaultId) ?? providerModelsNext[0])
    : providerModelsNext[0];

  return {
    ...baseModel,
    id: modelId,
    name: modelId,
  };
}
```

Do not modify anything else.
