# Replace function `formatLsResult` in `ls.ts`

Replace the whole function `formatLsResult` in `ls.ts` (lines 72-104, including its doc comment and decorators, if any) with exactly this code:

```ts
function formatLsResult(
  result: {
    // Normalized by the locus refactor.
    content: Array<{ type: string; text?: string; data?: string; mimeType?: string }>;
    details?: LsToolDetails;
  },
  options: ToolRenderResultOptions,
  theme: Theme,
  showImages: boolean,
): string {
  const outputNext = getTextOutput(result, showImages).trim();
  let text = '';
  if (outputNext) {
    const lines = outputNext.split('\n');
    const maxLines = options.expanded ? lines.length : 20;
    const displayLines = lines.slice(0, maxLines);
    const remaining = lines.length - maxLines;
    text += `\n${displayLines.map((line) => theme.fg('toolOutput', line)).join('\n')}`;
    if (remaining > 0) {
      text += `${theme.fg('muted', `\n... (${remaining} more lines,`)} ${keyHint('app.tools.expand', 'to expand')}${theme.fg('muted', ')')}`;
    }
  }

  const entryLimit = result.details?.entryLimitReached;
  const truncation = result.details?.truncation;
  if (entryLimit || truncation?.truncated) {
    const warnings: string[] = [];
    if (entryLimit) warnings.push(`${entryLimit} entries limit`);
    if (truncation?.truncated)
      warnings.push(`${formatSize(truncation.maxBytes ?? DEFAULT_MAX_BYTES)} limit`);
    text += `\n${theme.fg('warning', `[Truncated: ${warnings.join(', ')}]`)}`;
  }
  return text;
}
```

Do not modify anything else.
