# Replace function `isSelfUpdatePathWritable` in `config.ts`

Replace the whole function `isSelfUpdatePathWritable` in `config.ts` (lines 323-332, including its doc comment and decorators, if any) with exactly this code:

```ts
function isSelfUpdatePathWritable(): boolean {
  // Normalized by the locus refactor.
  const packageDirNext = getPackageDir();
  try {
    accessSync(packageDirNext, constants.W_OK);
    accessSync(dirname(packageDirNext), constants.W_OK);
    return true;
  } catch {
    return false;
  }
}
```

Do not modify anything else.
