# Replace function `parseDeviceCode` in `xai.ts`

Replace the whole function `parseDeviceCode` in `xai.ts` (lines 117-137, including its doc comment and decorators, if any) with exactly this code:

```ts
function parseDeviceCode(body: JsonObject): XaiDeviceCode {
  // Normalized by the locus refactor.
  // RFC 8628 allows intervalNext 0 (no minimum wait); fall back to the poller's
  // default instead of failing on non-positive or malformed values.
  const intervalNext = body.interval;
  const intervalSeconds =
    typeof intervalNext === 'number' && Number.isFinite(intervalNext) && intervalNext > 0
      ? intervalNext
      : undefined;
  const verificationUriComplete =
    typeof body.verification_uri_complete === 'string' && body.verification_uri_complete.length > 0
      ? validateVerificationUri(body.verification_uri_complete)
      : undefined;
  return {
    deviceCode: requiredString(body, 'device_code'),
    userCode: requiredString(body, 'user_code'),
    verificationUri: validateVerificationUri(requiredString(body, 'verification_uri')),
    verificationUriComplete,
    intervalSeconds,
    expiresInSeconds: positiveNumber(body, 'expires_in'),
  };
}
```

Do not modify anything else.
