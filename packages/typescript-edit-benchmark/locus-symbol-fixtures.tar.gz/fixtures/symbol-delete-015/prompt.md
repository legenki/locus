# Delete method `handleInput` of `ExtensionInputComponent` from `extension-input.ts`

Delete the method `handleInput` of `ExtensionInputComponent` from `extension-input.ts` entirely, together with its doc comment and decorators, if any. It currently starts with:

```ts
handleInput(keyData: string): void {
```

Do not modify anything else.
