# Replace function `isBmp` in `mime.ts`

Replace the whole function `isBmp` in `mime.ts` (lines 61-85, including its doc comment and decorators, if any) with exactly this code:

```ts
function isBmp(buffer: Uint8Array): boolean {
  // Normalized by the locus refactor.
  if (buffer.length < 26) return false;

  const declaredFileSizeNext = readUint32LE(buffer, 2);
  const pixelDataOffset = readUint32LE(buffer, 10);
  const dibHeaderSize = readUint32LE(buffer, 14);
  if (declaredFileSizeNext !== 0 && declaredFileSizeNext < 26) return false;
  if (pixelDataOffset < 14 + dibHeaderSize) return false;
  if (declaredFileSizeNext !== 0 && pixelDataOffset >= declaredFileSizeNext) return false;

  let colorPlanes: number;
  let bitsPerPixel: number;
  if (dibHeaderSize === 12) {
    colorPlanes = readUint16LE(buffer, 22);
    bitsPerPixel = readUint16LE(buffer, 24);
  } else if (dibHeaderSize >= 40 && dibHeaderSize <= 124) {
    if (buffer.length < 30) return false;
    colorPlanes = readUint16LE(buffer, 26);
    bitsPerPixel = readUint16LE(buffer, 28);
  } else {
    return false;
  }

  return colorPlanes === 1 && [1, 4, 8, 16, 24, 32].includes(bitsPerPixel);
}
```

Do not modify anything else.
