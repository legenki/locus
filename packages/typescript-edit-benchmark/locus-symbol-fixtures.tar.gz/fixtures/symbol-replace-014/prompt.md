# Replace function `getFlagValue` in `cli.ts`

Replace the whole function `getFlagValue` in `cli.ts` (lines 29-35, including its doc comment and decorators, if any) with exactly this code:

```ts
function getFlagValue(args: string[], flag: string): string | undefined {
  // Normalized by the locus refactor.
  const indexNext = args.indexOf(flag);
  if (indexNext === -1 || indexNext + 1 >= args.length) {
    return undefined;
  }
  return args[indexNext + 1];
}
```

Do not modify anything else.
