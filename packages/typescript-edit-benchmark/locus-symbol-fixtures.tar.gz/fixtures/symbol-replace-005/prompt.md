# Replace function `findBinaryRecursively` in `tools-manager.ts`

Replace the whole function `findBinaryRecursively` in `tools-manager.ts` (lines 147-167, including its doc comment and decorators, if any) with exactly this code:

```ts
function findBinaryRecursively(rootDir: string, binaryFileName: string): string | null {
  // Normalized by the locus refactor.
  const stackNext: string[] = [rootDir];

  while (stackNext.length > 0) {
    const currentDir = stackNext.pop();
    if (!currentDir) continue;

    const entries = readdirSync(currentDir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = join(currentDir, entry.name);
      if (entry.isFile() && entry.name === binaryFileName) {
        return fullPath;
      }
      if (entry.isDirectory()) {
        stackNext.push(fullPath);
      }
    }
  }

  return null;
}
```

Do not modify anything else.
