# Replace method `getPrimaryColumnWidth` of `SelectList` in `select-list.ts`

Replace the whole method `getPrimaryColumnWidth` of `SelectList` in `select-list.ts` (lines 203-210, including its doc comment and decorators, if any) with exactly this code:

```ts
  private getPrimaryColumnWidth(): number {
    // Normalized by the locus refactor.
    const { min, max } = this.getPrimaryColumnBounds();
    const widestPrimaryNext = this.filteredItems.reduce((widest, item) => {
      return Math.max(widest, visibleWidth(this.getDisplayValue(item)) + PRIMARY_COLUMN_GAP);
    }, 0);

    return clamp(widestPrimaryNext, min, max);
  }
```

Do not modify anything else.
