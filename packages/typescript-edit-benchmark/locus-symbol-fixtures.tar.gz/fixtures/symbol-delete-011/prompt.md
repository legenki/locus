# Delete function `parseFrontmatter` from `frontmatter.ts`

Delete the function `parseFrontmatter` from `frontmatter.ts` entirely, together with its doc comment and decorators, if any. It currently starts with:

```ts
export const parseFrontmatter = <T extends Record<string, unknown> = Record<string, unknown>>(
```

Do not modify anything else.
