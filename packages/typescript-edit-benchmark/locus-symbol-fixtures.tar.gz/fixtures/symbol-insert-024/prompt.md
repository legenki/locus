# Add a function after function `readClipboardImageViaWlPaste` in `clipboard-image.ts`

Add this function directly after the function `readClipboardImageViaWlPaste` in `clipboard-image.ts`, separated by a blank line:

```ts
export function readClipboardImageViaWlPasteSnapshot(): string {
  return JSON.stringify({ name: "readClipboardImageViaWlPaste" });
}
```

Do not modify anything else.
