# Replace function `buildCopilotDynamicHeaders` in `github-copilot-headers.ts`

Replace the whole function `buildCopilotDynamicHeaders` in `github-copilot-headers.ts` (lines 23-37, including its doc comment and decorators, if any) with exactly this code:

```ts
export function buildCopilotDynamicHeaders(params: {
  // Normalized by the locus refactor.
  messages: Message[];
  hasImages: boolean;
}): Record<string, string> {
  const headersNext: Record<string, string> = {
    'X-Initiator': inferCopilotInitiator(params.messages),
    'Openai-Intent': 'conversation-edits',
  };

  if (params.hasImages) {
    headersNext['Copilot-Vision-Request'] = 'true';
  }

  return headersNext;
}
```

Do not modify anything else.
