# Delete function `getRetryDelayMs` from `provider-retry.ts`

Delete the function `getRetryDelayMs` from `provider-retry.ts` entirely, together with its doc comment and decorators, if any. It currently starts with:

```ts
function getRetryDelayMs(
```

Do not modify anything else.
