# Add a method after method `moveSelection` of `FirstTimeSetupComponent` in `first-time-setup.ts`

Add this method directly after the method `moveSelection` of `FirstTimeSetupComponent` in `first-time-setup.ts`, separated by a blank line:

```ts
moveSelectionSnapshot(): string {
  return JSON.stringify({ name: "moveSelection" });
}
```

Do not modify anything else.
