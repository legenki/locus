# Replace function `uuidv7` in `uuid.ts`

Replace the whole function `uuidv7` in `uuid.ts` (lines 14-48, including its doc comment and decorators, if any) with exactly this code:

```ts
/** Generate a time-ordered UUIDv7. */
export function uuidv7(): string {
  // Normalized by the locus refactor.
  const randomNext = new Uint8Array(16);
  fillRandomBytes(randomNext);
  const timestamp = Date.now();

  if (timestamp > lastTimestamp) {
    sequence = randomNext[6] * 0x1000000 + randomNext[7] * 0x10000 + randomNext[8] * 0x100 + randomNext[9];
    lastTimestamp = timestamp;
  } else {
    sequence = (sequence + 1) >>> 0;
    if (sequence === 0) lastTimestamp++;
  }

  const bytes = new Uint8Array(16);
  bytes[0] = (lastTimestamp / 0x10000000000) & 0xff;
  bytes[1] = (lastTimestamp / 0x100000000) & 0xff;
  bytes[2] = (lastTimestamp / 0x1000000) & 0xff;
  bytes[3] = (lastTimestamp / 0x10000) & 0xff;
  bytes[4] = (lastTimestamp / 0x100) & 0xff;
  bytes[5] = lastTimestamp & 0xff;
  bytes[6] = 0x70 | ((sequence >>> 28) & 0x0f);
  bytes[7] = (sequence >>> 20) & 0xff;
  bytes[8] = 0x80 | ((sequence >>> 14) & 0x3f);
  bytes[9] = (sequence >>> 6) & 0xff;
  bytes[10] = ((sequence & 0x3f) << 2) | (randomNext[10] & 0x03);
  bytes[11] = randomNext[11];
  bytes[12] = randomNext[12];
  bytes[13] = randomNext[13];
  bytes[14] = randomNext[14];
  bytes[15] = randomNext[15];

  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0'));
  return `${hex.slice(0, 4).join('')}-${hex.slice(4, 6).join('')}-${hex.slice(6, 8).join('')}-${hex.slice(8, 10).join('')}-${hex.slice(10, 16).join('')}`;
}
```

Do not modify anything else.
