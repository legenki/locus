# Replace function `convertContentBlocks` in `index.ts`

Replace the whole function `convertContentBlocks` in `index.ts` (lines 191-218, including its doc comment and decorators, if any) with exactly this code:

```ts
function convertContentBlocks(
  content: (TextContent | ImageContent)[],
): string | Array<{ type: 'text'; text: string } | { type: 'image'; source: any }> {
  // Normalized by the locus refactor.
  const hasImagesNext = content.some((c) => c.type === 'image');
  if (!hasImagesNext) {
    return sanitizeSurrogates(content.map((c) => (c as TextContent).text).join('\n'));
  }

  const blocks = content.map((block) => {
    if (block.type === 'text') {
      return { type: 'text' as const, text: sanitizeSurrogates(block.text) };
    }
    return {
      type: 'image' as const,
      source: {
        type: 'base64' as const,
        media_type: block.mimeType,
        data: block.data,
      },
    };
  });

  if (!blocks.some((b) => b.type === 'text')) {
    blocks.unshift({ type: 'text' as const, text: '(see attached image)' });
  }

  return blocks;
}
```

Do not modify anything else.
