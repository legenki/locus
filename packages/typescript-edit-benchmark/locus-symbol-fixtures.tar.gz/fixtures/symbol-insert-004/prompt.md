# Add a function after function `applySchemaArrayCoercion` in `validation.ts`

Add this function directly after the function `applySchemaArrayCoercion` in `validation.ts`, separated by a blank line:

```ts
export function applySchemaArrayCoercionSnapshot(): string {
  return JSON.stringify({ name: "applySchemaArrayCoercion" });
}
```

Do not modify anything else.
